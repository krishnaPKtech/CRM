<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">

            <div class="container-fluid">
                <div class="card m-b-20">
                          <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to Customer Master List
        </li>
    </ol>
</div>
                            <div class="card-body">

                                <h4 class="mt-0 header-title">Import Customer</h4>
                                <p class="text-muted m-b-30 ">The first line in downloaded csv file should remain as it is. Please do not change the order of columns.</p>
                                <p>The Correct column Order is<span>(Cust ID,Cust Name,Contact,Region,Address,Status )</span></p>
                                <a class="btn btn-info" href="Customer.csv" download="Customer.csv"><i class="fas fa-download"></i>Download Sample File</a>
                                <form action="#">
                                    <div class="form-group">
                                        <label>Default file input</label>
                                        <input type="file" class="filestyle" data-buttonname="btn-secondary" id="filestyle-0" tabindex="-1" style="position: absolute; clip: rect(0px, 0px, 0px, 0px);"><div class="bootstrap-filestyle input-group"><input type="text" class="form-control " placeholder="" disabled=""> <span class="group-span-filestyle input-group-append" tabindex="0"><label for="filestyle-0" class="btn btn-secondary "><span class="icon-span-filestyle fas fa-folder-open"></span> <span class="buttonText">Choose file</span></label></span></div>
                                    </div>
                                                       <input type="submit" name="btnsave" class="btn btn-info">   
                 


                                </form>
                            </div>
                        </div>
                   
                                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>

        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

<?php include('includes/script-bottom.php'); ?>

    </body>
</html>