<?php include('includes/head.php'); ?>
        <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                                                                    <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to User List
        </li>
    </ol>
</div>
                            <div class="card-body">

                                <h4 class="mt-0 header-title">Create User</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                 <label>User ID</label>
                                                  <input type="text" class="form-control" placeholder="User ID">
                                                </div>
                                                <div class="form-group">
                                                    <label>User Name</label>
                                                    <input type="text" class="form-control" placeholder="User Name">
                                                </div>
                                    
                                            </div>
                                            <div class="col-md-6">
                                                <img id="blah" src="assets/images/upload.png" alt="your image" width="100" height="100" />

                                  <input type="file" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">User Roll</label>
                                        <input type="text" class="form-control" placeholder="User Roll">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Date of Joining</label>
                                                    <input type="date" class="form-control" >
                                                </div>    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">Contact</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">Aadhaar</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">E-Mail</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">PAN</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">Address</label>
                                       <textarea type="text" class="form-control" placeholder=""></textarea>
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">Bank Name</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">Blood Group</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">Acc No</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">D.O.B</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">IFSC Code</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">Referer Name</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">Contact Name</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                              <div class="form-group">
                                        <label class="control-label">Referer Info</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label class="control-label">Relation</label>
                                       <input type="text" class="form-control" placeholder="">
                                    </div>
                                                    
                                            </div>
                                            <div class="col-md-6">
                                                
                                                        <div class="form-group">
                                        <label>Status</label><br>
                                                    <label for="active">Active</label>
                                                      <input type="radio" name="rs" id="active" value="Active" checked>
                                                      <label for="inactive">In Active</label>
                                                     <input type="radio" name="rs" id="inactive" value="Inactive">
                                       
                                    </div>
                                                    
                                            </div>
                                            
                                            
                                            
                                        </div>
                                    </div> 
                                    
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <input type="submit" name="btnsave" value="Save&Next" class="btn btn-info"> 
                                                       <input type="submit" name="btnsave" value="Save" class="btn btn-success"> 
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                                
            </div> <!-- end container    -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>

        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>

    </body>
</html>