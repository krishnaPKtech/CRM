<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                                                                    <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to User Roll List
        </li>
    </ol>
</div>
                            <div class="card-body">

                                <h4 class="mt-0 header-title">Create User Roll</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                 <label>User ID</label>
                                                  <input type="text" class="form-control" placeholder="User ID">
                                                </div>
                                                
                                    
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>User Name</label>
                                                    <input type="text" class="form-control" placeholder="User Name">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                          <div class="card m-b-20">
                            <div class="card-body">

                                <h4 class="mt-0 header-title">Menu Access Permission</h4>
                                <p class="text-muted m-b-30 ">Create/Read/Update/Delete</p>


                                <div id="accordion">
                                    <div class="card mb-1">
                                        <div class="card-header p-3" id="headingOne">
                                            <h6 class="m-0 font-14">
                                                <a href="#collapseOne" class="text-dark" data-toggle="collapse"
                                                        aria-expanded="true"
                                                        aria-controls="collapseOne">
                                                     Masters
                                                    
                                                </a>
                                                <!--<a href="#collapseOne" style="float:right;"><i class="fas fa-angle-down"></i></a>-->
                                            </h6>
                                        </div>

                                        <div id="collapseOne" class="collapse"
                                                aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Customer Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Product Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Region Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        User Roll Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        User Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Expense Master       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card mb-1">
                                        <div class="card-header p-3" id="headingTwo">
                                            <h6 class="m-0 font-14">
                                                <a href="#collapseTwo" class="text-dark collapsed" data-toggle="collapse"
                                                        aria-expanded="false"
                                                        aria-controls="collapseTwo">
                                                    Marketing
                                                </a>
                                            </h6>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                                data-parent="#accordion">
                                            <div class="card-body">
                                               <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Leads       
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Follow Up
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Enquiries
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Enquiry Tickets
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                        Campaigns 
                                                        </div>
                                                        <div class="col-md-8">
                                                        <input type="checkbox" value="1" >Create
                                                        
                                                        &nbsp;
                                                        <input type="checkbox" value="1" >View
                                                        &nbsp;
                                                        
                                                        <input type="checkbox" value="2" >Edit
                                                        &nbsp;
                                                        <input type="checkbox" value="3" >Delete
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                    <!--<div class="card mb-1">-->
                                    <!--    <div class="card-header p-3" id="headingThree">-->
                                    <!--        <h6 class="m-0 font-14">-->
                                    <!--            <a href="#collapseThree" class="text-dark collapsed" data-toggle="collapse"-->
                                    <!--                    aria-expanded="false"-->
                                    <!--                    aria-controls="collapseThree">-->
                                    <!--                Region Master-->
                                    <!--            </a>-->
                                    <!--        </h6>-->
                                    <!--    </div>-->
                                    <!--    <div id="collapseThree" class="collapse"-->
                                    <!--            aria-labelledby="headingThree" data-parent="#accordion">-->
                                    <!--        <div class="card-body">-->
                                    <!--            <div class="col-md-12">-->
                                    <!--                <div class="row">-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >Create&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >View&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                                        
                                    <!--                    <input type="checkbox" value="2" >Edit&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="3" >Delete-->
                                    <!--                    </div>-->
                                    <!--                </div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <!--<div class="card mb-1">-->
                                    <!--    <div class="card-header p-3" id="headingfour">-->
                                    <!--        <h6 class="m-0 font-14">-->
                                    <!--            <a href="#collapsefour" class="text-dark collapsed" data-toggle="collapse"-->
                                    <!--                    aria-expanded="false"-->
                                    <!--                    aria-controls="collapsefour">-->
                                    <!--                Region Master-->
                                    <!--            </a>-->
                                    <!--        </h6>-->
                                    <!--    </div>-->
                                    <!--    <div id="collapsefour" class="collapse"-->
                                    <!--            aria-labelledby="headingfour" data-parent="#accordion">-->
                                    <!--        <div class="card-body">-->
                                    <!--            <div class="col-md-12">-->
                                    <!--                <div class="row">-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >Create&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >View&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                                        
                                    <!--                    <input type="checkbox" value="2" >Edit&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="3" >Delete-->
                                    <!--                    </div>-->
                                    <!--                </div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <!--<div class="card mb-1">-->
                                    <!--    <div class="card-header p-3" id="headingfive">-->
                                    <!--        <h6 class="m-0 font-14">-->
                                    <!--            <a href="#collapsefive" class="text-dark collapsed" data-toggle="collapse"-->
                                    <!--                    aria-expanded="false"-->
                                    <!--                    aria-controls="collapsefive">-->
                                    <!--                User Roll Master-->
                                    <!--            </a>-->
                                    <!--        </h6>-->
                                    <!--    </div>-->
                                    <!--    <div id="collapsefive" class="collapse"-->
                                    <!--            aria-labelledby="headingfive" data-parent="#accordion">-->
                                    <!--        <div class="card-body">-->
                                    <!--            <div class="col-md-12">-->
                                    <!--                <div class="row">-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >Create&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >View&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                                        
                                    <!--                    <input type="checkbox" value="2" >Edit&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="3" >Delete-->
                                    <!--                    </div>-->
                                    <!--                </div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <!--<div class="card mb-1">-->
                                    <!--    <div class="card-header p-3" id="headingsix">-->
                                    <!--        <h6 class="m-0 font-14">-->
                                    <!--            <a href="#collapsesix" class="text-dark collapsed" data-toggle="collapse"-->
                                    <!--                    aria-expanded="false"-->
                                    <!--                    aria-controls="collapsesix">-->
                                    <!--                User Master-->
                                    <!--            </a>-->
                                    <!--        </h6>-->
                                    <!--    </div>-->
                                    <!--    <div id="collapsesix" class="collapse"-->
                                    <!--            aria-labelledby="headingsix" data-parent="#accordion">-->
                                    <!--        <div class="card-body">-->
                                    <!--            <div class="col-md-12">-->
                                    <!--                <div class="row">-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >Create&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >View&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                                        
                                    <!--                    <input type="checkbox" value="2" >Edit&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="3" >Delete-->
                                    <!--                    </div>-->
                                    <!--                </div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <!--<div class="card mb-1">-->
                                    <!--    <div class="card-header p-3" id="headingseven">-->
                                    <!--        <h6 class="m-0 font-14">-->
                                    <!--            <a href="#collapseseven" class="text-dark collapsed" data-toggle="collapse"-->
                                    <!--                    aria-expanded="false"-->
                                    <!--                    aria-controls="collapseseven">-->
                                    <!--                Expense Master-->
                                    <!--            </a>-->
                                    <!--        </h6>-->
                                    <!--    </div>-->
                                    <!--    <div id="collapseseven" class="collapse"-->
                                    <!--            aria-labelledby="headingseven" data-parent="#accordion">-->
                                    <!--        <div class="card-body">-->
                                    <!--            <div class="col-md-12">-->
                                    <!--                <div class="row">-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >Create&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="1" >View&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                                        
                                    <!--                    <input type="checkbox" value="2" >Edit&nbsp;-->
                                                        
                                    <!--                    </div>-->
                                    <!--                    <div class="col-md-3">-->
                                    <!--                    <input type="checkbox" value="3" >Delete-->
                                    <!--                    </div>-->
                                    <!--                </div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                </div>

                            </div>
                        </div>
                                                    </div>
                                                </div>
                                               
                                                
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group" style="padding-top:30px;">
                                                    <label>Mobile App</label><br>
                                                    <label for="active">Active</label>
                                                      <input type="radio" name="rs" id="active" value="Active" checked>
                                                      <label for="inactive">In Active</label>
                                                     <input type="radio" name="rs" id="inactive" value="Inactive">
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                    
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <input type="submit" name="btnsave" value="Save" class="btn btn-success"> 
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                               
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>

        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>

    </body>
</html>