<?php // require'db.php';?>
<?php
$m_no = $_GET['scno'];
  $m_no = intval($_GET['scno']);
//$m_no = $_GET['m_no'];
 if(isset($_GET['scno'])){

 

	$sql = "SELECT * FROM servicetneb where sno = '".$m_no."'";
    $result = mysqli_query($conn,$sql);
	if($row = mysqli_fetch_assoc($result)) {
	    $b_name = $row['name'];
	    echo'<div class="row">';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>Designation</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" value="'.$b_name.'">';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>Mobile</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" value="'.$b_name.'">';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>E-Mail</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" value="'.$b_name.'">';
        echo'</div>';
        echo'</div>';
        echo'</div>';
}else{
    echo'<div class="row">';
    echo'<div class="col-md-4">';
    echo'<div class="form-group">';
        
        echo '<label>Designation</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>Mobile</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>E-Mail</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'</div>';
}

}else{
    echo'<div class="row">';
    echo'<div class="col-md-4">';
    echo'<div class="form-group">';
        
        echo '<label>Designation</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>Mobile</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'<div class="col-md-4">';
        echo'<div class="form-group">';
        
        echo '<label>E-Mail</label>
        <input type="text" class="form-control" tabindex="2" style="text-align:center;" name="name" >';
        echo'</div>';
        echo'</div>';
        echo'</div>';
}
?>