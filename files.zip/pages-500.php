<?php include('includes/head.php'); ?>

<?php include('includes/css.php'); ?>

    <body>

        <!-- Begin page -->
        <div class="wrapper-page">

            <div class="card">
                <div class="card-block">

                    <div class="ex-page-content text-center">
                        <h1 class="text-dark">500</h1>
                        <h4 class="">Internal Server Error</h4><br>

                        <a class="btn btn-info mb-5 waves-effect waves-light" href="index.php"><i class="mdi mdi-home"></i> Back to Dashboard</a>
                    </div>

                </div>
            </div>

            <div class="m-t-40 text-center">
                <p>© <?php echo date('Y');?> Lexa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>
            </div> 

        </div>

<?php include('includes/script.php'); ?>

        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

<?php include('includes/script-bottom.php'); ?>

    </body>
</html>