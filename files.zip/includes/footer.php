		<!-- Footer -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <p>© <?php echo date('Y');?> & Powered by Largstone Pvt Ltd</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->