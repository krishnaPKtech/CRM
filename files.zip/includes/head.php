<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Purple - CRM</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">
        <style>
            .has-submenu::hover{
                background-color:purple;
                color:white;
            }
            .submenu::hover{
                background-color:purple;
                color:white;
            }
        </style>
