
<style>
    
#navigation .navigation-menu .has-submenu > li > a:focus, #navigation .navigation-menu .has-submenu > li > a:hover {
  /*background-color: rgba(42, 49, 66, 0.1);*/
  background-color: Purple;
  /*color: #2a3142;*/
  color: yellow;
}
</style>
            <!-- MENU Start -->
            <div class="navbar-custom" style="background-color: whitesmoke;text-align:center;">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="welcome.php">
                                    <!--<i class="ti-dashboard"></i>-->
                                    <i class="bi bi-speedometer"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li> 

                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-journals"></i>Masters</a>
                                <ul class="submenu">
                                    <li><a href="crm-customer.php">Customer Master</a></li>
                                    <li><a href="crm-product.php">Product Master</a></li>
                                    <!--<li><a href="#">Service Schedule Master</a></li>-->
                                    <li><a href="crm-region.php">Region Master</a></li>
                                    <li><a href="crm-userroll.php">User Roll Master</a></li>
                                    <li><a href="crm-user.php">User Master</a></li>
                                    <li><a href="crm-expense.php">Expense Type Master</a></li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-megaphone"></i>Marketing</a>
                                <ul class="submenu ">
                                    <li>
                                        <ul>
                                            <li><a href="crm-leads.php">Leads</a></li>
                                            <li><a href="crm-followup.php">Follow Up</a></li>
                                            <li><a href="crm-enquiry.php">Enquiries</a></li>
                                            <li><a href="crm-enquiry-tickets.php">Enquiry Tickets</a></li>
                                            <li><a href="crm-campaigns.php">Campaigns</a></li>
                                            <!--<li><a href="ui-dropdowns.php">Dropdowns</a></li>-->
                                        </ul>
                                    </li>
                                    
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-cash-coin"></i>Sales</a>
                                <ul class="submenu">
                                    <li><a href="crm-sales-quotation.php">Quotation</a></li>
                                    <li><a href="crm-sales-order.php">Sales Order</a></li>
                                    <li><a href="crm-invoices.php">Invoice</a></li>
                                    <li><a href="crm-sales-ledger.php">Sales Ledger</a></li>
                                    <li><a href="crm-targets.php">Targets</a></li>
                                    <!-- <li><a href="form-xeditable.php">Xeditable</a></li> -->
                                </ul>
                            </li>

                            

                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-wrench-adjustable-circle"></i>Services</a>
                                <ul class="submenu">
                                    <li><a href="crm-service-tickets.php">Service Tickets</a></li>
                                    <li><a href="crm-service-invoice.php">Service Invoices</a></li>
                                    <li><a href="crm-service-ledger.php">Service Ledger</a></li>
                                    
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-headset"></i>Customer Support</a>
                                <ul class="submenu">
                                    
                                            <li><li class="has-submenu"><a href="crm-call-desk.php">Call Desk</a>
                                            <ul class="submenu">
                                            <li><a href="crm-call-service.php">Service</a></li>
                                            <li><a href="crm-call-enquiry.php">Enquiry</a></li>
                                            <li><a href="crm-call-feedback.php">Feedback</a></li>
                                            <li><a href="crm-call-complaints.php">Complaint</a></li>
                                            
                                        </ul>
                                            </li>
                                            <li><a href="crm-tickets.php">Tickets</a></li>
                                            <!--<li><a href="crm-ticket-ledger.php">Ticket Ledger</a></li>-->
                                            
                                        
                                    <li>
                                        <!--<li class="has-submenu">-->
                                        <a href="crm-feedbacks.php">Feedbacks</a>
                                        <!--<ul class="submenu">-->
                                        <!--    <li><a href="icons-material.php">Marketing</a></li>-->
                                        <!--    <li><a href="icons-ion.php">Sales</a></li>-->
                                        <!--    <li><a href="icons-fontawesome.php">Delivery</a></li>-->
                                        <!--    <li><a href="icons-themify.php">User Experience</a></li>-->
                                            
                                        <!--</ul>-->
                                    <!--</li>-->
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-patch-question-fill"></i>R&D</a>
                                <ul class="submenu">
                                    <li><a href="crm-refrences.php">References</a></li>
                                    <li><a href="crm-doc-medias.php">Docs & Medias</a></li>
                                    <li><a href="crm-surveys.php">Surveys</a></li>
                                    
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-calculator"></i>Accounts</a>
                                <ul class="submenu">
                                    <li><a href="crm-outstanding.php">Outstandings</a></li>
                                    <li><a href="crm-collections.php">Collections</a></li>
                                    <li><a href="crm-expense-ledger.php">Expense Ledger</a></li>
                                    
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a href="#"><i class="bi bi-graph-up-arrow"></i>Reports</a>
                                <ul class="submenu">
                                    <li><a href="#">Leads Report</a></li>
                                    <li><a href="#">Quotations Report</a></li>
                                    <li><a href="#">Target Report</a></li>
                                    <li><a href="#">Enquiries Report</a></li>
                                    <li><a href="#">Expences Report</a></li>
                                    <li><a href="#">Surveys Report</a></li>
                                    <li><a href="#">Campaigns Report</a></li>
                                    
                                </ul>
                            </li>
                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div> <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->
