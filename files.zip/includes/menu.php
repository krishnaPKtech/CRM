            <!-- MENU Start -->
            <div class="navbar-custom">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="index.php">
                                    <i class="ti-dashboard"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-email"></i>Email</a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.php">Inbox</a></li>
                                    <li><a href="email-read.php">Email Read</a></li>
                                    <li><a href="email-compose.php">Email Compose</a></li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-support"></i>UI Elements</a>
                                <ul class="submenu megamenu">
                                    <li>
                                        <ul>
                                            <li><a href="ui-alerts.php">Alerts</a></li>
                                            <li><a href="ui-buttons.php">Buttons</a></li>
                                            <li><a href="ui-badge.php">Badge</a></li>
                                            <li><a href="ui-cards.php">Cards</a></li>
                                            <li><a href="ui-carousel.php">Carousel</a></li>
                                            <li><a href="ui-dropdowns.php">Dropdowns</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <ul>
                                            <li><a href="ui-grid.php">Grid</a></li>
                                            <li><a href="ui-images.php">Images</a></li>
                                            <li><a href="ui-lightbox.php">Lightbox</a></li>
                                            <li><a href="ui-modals.php">Modals</a></li>
                                            <li><a href="ui-pagination.php">Pagination</a></li>
                                            <li><a href="ui-popover-tooltips.php">Popover & Tooltips</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <ul>
                                            <li><a href="ui-progressbars.php">Progress Bars</a></li>
                                            <li><a href="ui-sweet-alert.php">Sweet-Alert</a></li>
                                            <li><a href="ui-tabs-accordions.php">Tabs &amp; Accordions</a></li>
                                            <li><a href="ui-typography.php">Typography</a></li>
                                            <li><a href="ui-video.php">Video</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-receipt"></i>Forms</a>
                                <ul class="submenu">
                                    <li><a href="form-elements.php">Elements</a></li>
                                    <li><a href="form-validation.php">Validation</a></li>
                                    <li><a href="form-advanced.php">Advanced</a></li>
                                    <li><a href="form-editors.php">Editors</a></li>
                                    <li><a href="form-uploads.php">File Upload</a></li>
                                    <li><a href="form-xeditable.php">Xeditable</a></li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-menu-alt"></i>More</a>
                                <ul class="submenu">
                                    <li>
                                        <a href="calendar.php">Calendar</a>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="#">Icons</a>
                                        <ul class="submenu">
                                            <li><a href="icons-material.php">Material Design</a></li>
                                            <li><a href="icons-ion.php">Ion Icons</a></li>
                                            <li><a href="icons-fontawesome.php">Font Awesome</a></li>
                                            <li><a href="icons-themify.php">Themify Icons</a></li>
                                            <li><a href="icons-dripicons.php">Dripicons</a></li>
                                            <li><a href="icons-typicons.php">Typicons Icons</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="#">Tables </a>
                                        <ul class="submenu">
                                            <li><a href="tables-basic.php">Basic Tables</a></li>
                                            <li><a href="tables-datatable.php">Data Table</a></li>
                                            <li><a href="tables-responsive.php">Responsive Table</a></li>
                                            <li><a href="tables-editable.php">Editable Table</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="#">Maps</a>
                                        <ul class="submenu">
                                            <li><a href="maps-google.php"> Google Map</a></li>
                                            <li><a href="maps-vector.php"> Vector Map</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="rangeslider.php">Range Slider</a>
                                    </li>
                                    <li>
                                        <a href="session-timeout.php">Session Timeout</a>
                                    </li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-pie-chart"></i>Charts</a>
                                <ul class="submenu">
                                    <li><a href="charts-morris.php">Morris Chart</a></li>
                                    <li><a href="charts-chartist.php">Chartist Chart</a></li>
                                    <li><a href="charts-chartjs.php">Chartjs Chart</a></li>
                                    <li><a href="charts-flot.php">Flot Chart</a></li>
                                    <li><a href="charts-c3.php">C3 Chart</a></li>
                                    <li><a href="charts-other.php">Jquery Knob Chart</a></li>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="#"><i class="ti-files"></i>Pages</a>
                                <ul class="submenu megamenu">
                                    <li>
                                        <ul>
                                            <li><a href="pages-timeline.php">Timeline</a></li>
                                            <li><a href="pages-invoice.php">Invoice</a></li>
                                            <li><a href="pages-directory.php">Directory</a></li>
                                            <li><a href="pages-login.php">Login</a></li>
                                            <li><a href="pages-register.php">Register</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <ul>
                                            <li><a href="pages-recoverpw.php">Recover Password</a></li>
                                            <li><a href="pages-lock-screen.php">Lock Screen</a></li>
                                            <li><a href="pages-blank.php">Blank Page</a></li>
                                            <li><a href="pages-404.php">Error 404</a></li>
                                            <li><a href="pages-500.php">Error 500</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div> <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->
