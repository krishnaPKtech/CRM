<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                            <div class="card-body">
                                <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to Reference List
        </li>
    </ol>
</div>

                                <h4 class="mt-0 header-title">Add Reference</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Reference ID</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                                
                                    
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Refrence Name</label>
                                                    <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Date</label>
                                                    <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Reference Type</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                                
                                    
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Customer Name</label>
                                                    <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Created By</label>
                                                    <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                                <div class="card-body rssRowContainer">
												 <div class="row rssRow inputContainer" id="TargetElements">
												 <div class="col-md-3">
                                                  <div class="form-group ">
                                                    <label class="control-label">Reference Link </label>
													 <input type="text" id="txtName" name="txtName[]"  class="form-control" placeholder="" >
													 <span style="float:right" class="removeNode" >
                                                     <i class="fas fa-window-close" style="font-size:24px;color:red;cursor:pointer;"></i></span>
                                                  </div>
                                                 </div>
												 
                                                 </div>
                                                 </div>
                                                 <div> 
                                                 <input type="button" id="add-row" value="Add Row">
                                                 </div>
                                                 
                                            </div>
                                            <div class="row">
                                                <div class="card-body rssRowContainern">
												 <div class="row rssRown inputContainern" id="TargetElementsn">
												 <div class="col-md-3">
                                                  <div class="form-group ">
                                                    <label class="control-label">Title </label>
													 <input type="text" id="txtName" name="txtName[]"  class="form-control" placeholder="" >
                                                  </div>
                                                 </div>
												 <div class="col-md-9">
                                                  <div class="form-group ">
                                                    <label class="control-label">Note </label>
													 <textarea class="form-control"></textarea>
													 <span style="float:right" class="removeNoden" >
                                                     <i class="fas fa-window-close" style="font-size:24px;color:red;cursor:pointer;"></i></span>
                                                  </div>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 <div> 
                                                 <input type="button" id="add-rown" value="Add Row">
                                                 </div>
                                                 
                                            </div>
                                            <div class="row">
                                                
                                            </div>
                                    </div>
                                    
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <input type="submit" name="btnsave" value="Save&Next" class="btn btn-info"> 
                                                       <input type="submit" name="btnsave" value="Save" class="btn btn-success"> 
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                                    </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>

        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>
<script src="http://code.jquery.com/jquery.js"></script>
      <script  >
      $.noConflict();
      $('#add-row').click(function() {
        //   var txtName = document.getElementById("txtName");
        //     var txtDesig = document.getElementById("txtDesig");
        //     var txtMobile = document.getElementById("txtMobile");
        //     var txtEmail = document.getElementById("txtEmail");
           
        //     txtName.value = "";
        //     txtDesig.value="";
        //     txtMobile.value="";txtEmail.value="";
    var row = jQuery('.rssRowContainer .rssRow').clone(true);
     jQuery('#txtName', row).attr('id', 'txtName').val("");
//     jQuery('#txtGender', row).attr('id', 'txtGender').val('');
    
    
//     jQuery('.txtAge', row).attr('id', 'txtAge').val('');
    
//     var original = $("#txtGender");
// var clone = original.clone();

//clone.select2();
  jQuery('.rssRowContainer').append(row).find("input[type='text']").val("");
            
//   var new_row = ('#txtGender').select2();
  });
  
  $('body').on('click','.removeNode', function() {
    $(this).closest('.rssRow').remove();
  });
   $('#add-rown').click(function() {
    var row = jQuery('.rssRowContainern .rssRown').clone(true);
     jQuery('.rssRowContainern').append(row);
     $('body').on('click','.removeNoden', function() {
     $(this).closest('.rssRown').remove();
  });
   });
    </script>
    <script>
     // $.noConflict();
     
    </script>
    </body>
</html>