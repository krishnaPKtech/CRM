<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                            <div class="card-body">
                                    <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to Follow Up List
        </li>
    </ol>
</div>

                                <h4 class="mt-0 header-title">Add Follow Up</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Lead ID</label>
                                                  <input type="text" class="form-control" placeholder="Lead ID">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Entry Date</label>
                                                    <input type="Date" class="form-control" placeholder="Region Name">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Created By</label>
                                                  <input type="text" class="form-control" placeholder="Created By">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Lead Type</label>
                                                  <input type="text" class="form-control" placeholder="Lead Type">
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                 <label>Lead Name</label>
                                                  <input type="text" class="form-control" placeholder="Created By">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Address Line 1</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Address Line 2</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Address Line 3</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>District</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>State</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Pincode</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            </div>
                                            
                                            <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Lead Follow Up</label>
                                                  <input type="text" class="form-control" placeholder="Property Type">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Next Follow Up</label>
                                                  <input type="text" class="form-control" placeholder="Bussiness Type">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label> Follow Up By</label>
                                                  <input type="text" class="form-control" placeholder="No of Unit">
                                                </div>
                                            </div>
                                            </div>
                                            <div class="row">
                                                <div class="card-body">
												 <div class="row " >
												 <div class="col-md-3">
                                                  <div class="form-group ">
                                                    <label class="control-label">Followed Person </label>
													 <input class="form-control" list="carsss" onkeyup="showMno(this.value)" id="scno" name="scno" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                                      <datalist tabindex="1" minlength="10" maxlength="10" name="scno" id="carsss">
                                                          <option value="">Select Employee</option>
                                                          <option>Raja</option>
                                                            <option>Ravi</option>
                                                        </datalist>
                                                  </div>
                                                 </div>
												 
                                                 
												 <div class="col-md-9 " id="livesearchMno">
												 
												 
                                                 </div>
                                                 </div>
                                                 
                                                 
                                            </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">Response</div>
                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                 <label></label>
                                                  <select class="form-control">
                                                      <option>Select Response</option>
                                                  </select>
                                                </div>
                                                </div>
                                                <!--<div class="col-md-5">-->
                                                <!--    <div class="form-group">-->
                                                <!-- <label>Establlished Date</label>-->
                                                <!--  <input type="date" class="form-control" placeholder="">-->
                                                <!--</div>-->
                                                <!--</div>-->
                                            </div>
                                            <div class="row">
                                                <div class="col-md-8">
                                                <label>Discussion's</label>
                                                <textarea class="form-control"></textarea>
                                                </div>
                                            <!--    <div class="col-md-4">-->
                                            <!--     <div class="form-group" style="padding-top:30px">-->
                                            <!--        <label>Status</label><br>-->
                                            <!--        <label for="active">Active</label>-->
                                            <!--          <input type="radio" name="rs" id="active" value="Active" checked>-->
                                            <!--          <label for="inactive">In Active</label>-->
                                            <!--         <input type="radio" name="rs" id="inactive" value="Inactive">-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            </div>
                                            
                                    </div>
                                    
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <input type="submit" name="btnsave" value="Save&Next" class="btn btn-info"> 
                                                       <input type="submit" name="btnsave" value="Save" class="btn btn-success"> 
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                          
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>
 <script>
function showMno(str) {
  if (str.length==0) {
    document.getElementById("livesearchMno").innerHTML="";
    document.getElementById("livesearchMno").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearchMno").innerHTML=this.responseText;
     // document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","crm-livesearching.php?scno="+str,true);
  xmlhttp.send();
}
</script>
        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>
<script src="http://code.jquery.com/jquery.js"></script>
      <script  >
      $.noConflict();
      $('#add-row').click(function() {
        //   var txtName = document.getElementById("txtName");
        //     var txtDesig = document.getElementById("txtDesig");
        //     var txtMobile = document.getElementById("txtMobile");
        //     var txtEmail = document.getElementById("txtEmail");
           
        //     txtName.value = "";
        //     txtDesig.value="";
        //     txtMobile.value="";txtEmail.value="";
    var row = jQuery('.rssRowContainer .rssRow').clone(true);
     jQuery('#txtName', row).attr('id', 'txtName').val("");
//     jQuery('#txtGender', row).attr('id', 'txtGender').val('');
    
    
//     jQuery('.txtAge', row).attr('id', 'txtAge').val('');
    
//     var original = $("#txtGender");
// var clone = original.clone();

//clone.select2();
  jQuery('.rssRowContainer').append(row).find("input[type='text']").val("");
            
//   var new_row = ('#txtGender').select2();
  });
  
  $('body').on('click','.removeNode', function() {
    $(this).closest('.rssRow').remove();
  });
   $('#add-rown').click(function() {
    var row = jQuery('.rssRowContainern .rssRown').clone(true);
     jQuery('.rssRowContainern').append(row);
     $('body').on('click','.removeNoden', function() {
     $(this).closest('.rssRown').remove();
  });
   });
    </script>
    <script>
     // $.noConflict();
     
    </script>
    </body>
</html>