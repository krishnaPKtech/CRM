<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                            <div class="card-body">
                                                          <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to Quotation List
        </li>
    </ol>
</div>

                                <h4 class="mt-0 header-title" align="center">Create Quotation</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        
                                <!--        <div></div>-->
                                <!--      <div align="center">-->
                                <!--        <div class="col-md-4">-->
                                <!--Quotation Number: <input type="text" class="form-control"/>-->
                                <!--</div></div>-->
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Enquiry Ref No</label>
                                                  <input type="text" class="form-control" placeholder="Lead ID">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Lead Name</label>
                                                    <input type="text" class="form-control" placeholder="Lead Name">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Type</label>
                                                  <select class="form-control">
                                                      <option>Select Type</option>
                                                  </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Enquiry Date</label>
                                                  <input type="date" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Quotation Date</label>
                                                  <input type="date" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>GSTIN</label>
                                                  <input type="text" class="form-control" placeholder="GSTIN">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Address</label>
                                                  <textarea type="text" class="form-control" placeholder=""></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Contact Person</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Mobile</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Estimated Delivery</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>valid Upto</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Shiping Mode</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Shiping Terms</label>
                                                  <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            </div>
                                            
                                            
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-3">Product</div>
                                                        <div class="col-md-9">
                                                            <div class="form-group">
                                                                <select class="form-control">
                                                                    <option value="">Select Product</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    
                                                    <div class="row">
                                                    <div class="table-responsive">
                                                        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                            <thead>
                                                                <th>S.No</th>
                                                                <th>Product Code</th>
                                                                <th>Product Name</th>
                                                                <th>Varient</th>
                                                                <th>Price</th>
                                                                <th>Qty</th>
                                                                <th>UOM</th>
                                                                <th>Amount</th>
                                                                <th>GST</th>
                                                                <th>Total</th>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>1</td>
                                                                    <td>110</td>
                                                                    <td>Pillow</td>
                                                                    <td>Varient</td>
                                                                    <td>5</td>
                                                                    <td>1</td>
                                                                    <td>3</td>
                                                                    <td>5</td>
                                                                    <td>1</td>
                                                                    <td></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-9">
                                                            <label>Terms & Conditions</label>
                                                            <textarea class="form-control"></textarea>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label>Gross Total</label>
                                                                <input type="text" class="form-control" >
                                                            
                                                                <label>GST Total</label>
                                                                <input type="text" class="form-control" >
                                                            
                                                                <label>Net Total</label>
                                                                <input type="text" class="form-control" >
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                    <div align="center" style="float:right">
                                                       <input type="button" class="btn btn-danger" value="Close" onclick="javascript:history.go(-1);" /> 
                                                       <input type="submit" name="btnsave" value="Submit(for approval)" class="btn btn-success"> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                          
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>
 <script>
function showMno(str) {
  if (str.length==0) {
    document.getElementById("livesearchMno").innerHTML="";
    document.getElementById("livesearchMno").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearchMno").innerHTML=this.responseText;
     // document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","crm-livesearching.php?scno="+str,true);
  xmlhttp.send();
}
</script>
        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>
<script src="http://code.jquery.com/jquery.js"></script>
      <script  >
      $.noConflict();
      $('#add-row').click(function() {
    var row = jQuery('.rssRowContainer .rssRow').clone(true);
     jQuery('#txtName', row).attr('id', 'txtName').val("");
  jQuery('.rssRowContainer').append(row).find("input[type='text']").val("");
  });
  
  $('body').on('click','.removeNode', function() {
    $(this).closest('.rssRow').remove();
  });
   $('#add-rown').click(function() {
    var row = jQuery('.rssRowContainern .rssRown').clone(true);
     jQuery('.rssRowContainern').append(row);
     $('body').on('click','.removeNoden', function() {
     $(this).closest('.rssRown').remove();
  });
   });
    </script>
    <script>
     // $.noConflict();
     
    </script>
    </body>
</html>