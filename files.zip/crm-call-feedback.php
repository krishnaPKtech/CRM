<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                            <div class="card-body">

                                <!--<h4 class="mt-0 header-title" align="center">Quotation Number: P101/2022 </h4>-->
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <b style="color:purple">Call From(Service)</b>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label style="float:right">Calls:</label>
                                                  
                                                  
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label for="active">In-call</label>
                                                      <input type="radio" name="rs" id="active" value="yes" >
                                                      <label for="inactive">Out-Call</label>
                                                     <input type="radio"  name="rs" id="inactive" value="no">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                <label for="active">Call Number</label>
                                                      <input type="text" class="form-control" name="rs" id="active" value="yes" >
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Call For</label>
                                                   <select class="form-control" placeholder="">
                                                      <option>Service</option>
                                                  </select>
                                                  
                                                </div>
                                            </div>
                                            <!--<div class="col-md-4">-->
                                            <!--    <div class="form-group">-->
                                            <!--        <label>Customer Type</label>-->
                                            <!--        <select class="form-control" placeholder="">-->
                                            <!--          <option>Select Customer</option>-->
                                            <!--      </select>-->
                                            <!--    </div>-->
                                            <!--</div>  -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Customer Name</label>
                                                    <select class="form-control" placeholder="">
                                                      <option>Select Customer</option>
                                                  </select>  
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                 
                                                
                                                <label>Select Product</label>
                                                    <select class="form-control" placeholder="">
                                                      <option>Select Product</option>
                                                  </select>
                                            </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                 <label>Specifications</label>
                                                    <select class="form-control" placeholder="">
                                                      <option>Select Type</option>
                                                  </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Feedback</label>
                                                    <select class="form-control" placeholder="">
                                                      <option>Select Type</option>
                                                  </select>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                 <label>Note</label>
                                              <input type="text" class="form-control" placeholder="">
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12">
                                                <div class="table-resposive">
                                                 <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                     <thead>
                                                         <th>S.No</th>
                                                         <th>Product</th>
                                                         <th>Specifications</th>
                                                         <th>Feedback</th>
                                                         <!--<th>Complaints</th>-->
                                                         <td>Actions</td>
                                                     </thead>
                                                     <tbody>
                                                         <tr>
                                                             <td>1</td>
                                                             <td>Product 1</td>
                                                             <td>Yes</td>
                                                             <td>
                                                                 <td>Good</td>
                                                                 <td><a href="#">Note</a></td>
                                                             
                                                             </td>
                                                            <td></td>
                                                         </tr>
                                                     </tbody>
                                                 </table>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 
                                                </div>
                                            </div>
                                            </div>
                                            
                                            
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <!--<input type="submit" name="btnsave" value="Save&Next" class="btn btn-info"> -->
                                                       
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                                       <input type="submit" name="btnsave" value="Generate Ticket" class="btn btn-success"> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                          
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>
 <script>
function showMno(str) {
  if (str.length==0) {
    document.getElementById("livesearchMno").innerHTML="";
    document.getElementById("livesearchMno").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearchMno").innerHTML=this.responseText;
     // document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","crm-livesearching.php?scno="+str,true);
  xmlhttp.send();
}
</script>
        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>
<script src="http://code.jquery.com/jquery.js"></script>
      
    </body>
</html>