<?php include('includes/head.php'); ?>
 <link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
        <link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
       <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<?php include('includes/css.php'); ?>
<style type="text/css">
    .wrappers{
        padding-top: 145px;
    }
</style>
    <body>

<?php include('includes/header.php'); ?>

            

<?php include('includes/menus.php'); ?>

        <div class="wrappers">
            <div class="container-fluid">
                <div class="card m-b-20">
                            <div class="card-body">
                                <div class="page-title-box">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" style="color:purple;cursor: pointer;" onclick="javascript:history.go(-1);">
            <i class="fas fa-arrow-left"></i>&nbsp;Back to Campaigns List
        </li>
    </ol>
</div>

                                <h4 class="mt-0 header-title">Create Campaigns</h4>
                                
                                <form action="#">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Campaign ID</label>
                                                  <input type="text" class="form-control" placeholder="Lead ID">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Campaign Name</label>
                                                    <input type="Date" class="form-control" placeholder="Region Name">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Type</label>
                                                  <input type="text" class="form-control" placeholder="Created By">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Mode</label>
                                                  <input type="text" class="form-control" placeholder="Lead Type">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Started Date</label>
                                                  <input type="date" class="form-control" placeholder="Created By">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                 <label>Valid till</label>
                                                  <input type="text" class="form-control" placeholder="Created By">
                                                </div>
                                            </div>
                                        </div>
                                            
                                            <div class="row">
                                                <div class="card-body rssRowContainer">
												 <div class="row rssRow inputContainer" id="TargetElements">
												 <div class="col-md-10">
                                                  <div class="form-group ">
                                                    <label class="control-label">Discription </label>
													 <textarea  id="txtName" name="txtName[]"  class="form-control" placeholder="" ></textarea>
                                                  </div>
                                                 </div>
                                                 <div class="col-md-2">
                                                  <div class="form-group ">
                                                    <span style="float:left" class="removeNode" >
                                                     <i class="fas fa-window-close" style="font-size:24px;color:red;cursor:pointer;padding-top:30px;"></i></span>
													 <span style="float:right" id="add-row">
                                                     <i class="fas fa-plus" style="font-size:24px;color:green;cursor:pointer;padding-top:30px;"></i></span>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 <!--<div style="float:left"> -->
                                                 <!--<input type="button"  value="Add Row">-->
                                                 <!--</div>-->
                                                 
                                            </div>
                                            <div class="row">
                                                <div class="card-body rssRowContainern">
												 <div class="row rssRown inputContainern" id="TargetElementsn">
												 <div class="col-md-10">
                                                  <div class="form-group ">
                                                    <img id="blah" src="assets/images/upload.png" alt="your image" width="100" height="100" />

                                                    <input type="file" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                                                  </div>
                                                 </div>
                                                 <div class="col-md-2">
                                                  <div class="form-group ">
                                                    <span style="float:left" class="removeNoden" >
                                                     <i class="fas fa-window-close" style="font-size:24px;color:red;cursor:pointer;padding-top:30px;"></i></span>
													 <span style="float:right" id="add-rown">
                                                     <i class="fas fa-plus" style="font-size:24px;color:green;cursor:pointer;padding-top:30px;"></i></span>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 <!--<div style="float:left"> -->
                                                 <!--<input type="button"  value="Add Row">-->
                                                 <!--</div>-->
                                                 
                                            </div>
                                            <div class="row">
                                                <div class="card-body rssRowContainerm">
												 <div class="row rssRowm inputContainerm" id="TargetElementsm">
												 <div class="col-md-10">
                                                  <div class="form-group ">
                                                    <img id="blah" src="assets/images/upload.png" alt="your image" width="100" height="100" />

                                                    <input type="file" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                                                  </div>
                                                 </div>
                                                 <div class="col-md-2">
                                                  <div class="form-group ">
                                                    <span style="float:left" class="removeNodem" >
                                                     <i class="fas fa-window-close" style="font-size:24px;color:red;cursor:pointer;padding-top:30px;"></i></span>
													 <span style="float:right" id="add-rowm">
                                                     <i class="fas fa-plus" style="font-size:24px;color:green;cursor:pointer;padding-top:30px;"></i></span>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 </div>
                                                 <!--<div style="float:left"> -->
                                                 <!--<input type="button"  value="Add Row">-->
                                                 <!--</div>-->
                                                 
                                            </div>
                                            <div class="row">
                                                
                                                <div class="col-md-4">
                                                 <div class="form-group" style="padding-top:30px">
                                                    <label></label><br>
                                                    <label for="active">Active</label>
                                                      <input type="radio" name="rs" id="active" value="yes" >
                                                      <label for="inactive">In active</label>
                                                     <input type="radio" name="rs" id="inactive" value="no">
                                                </div>
                                            </div>
                                            </div>
                                            
                                    </div>
                                                    
                                    <div align="center" style="float:right">
                                                       <input type="reset" name="clear" value="Clear" class="btn btn-warning"> 
                                                       <input type="submit" name="btnsave" value="Save&Next" class="btn btn-info"> 
                                                       <input type="submit" name="btnsave" value="Save" class="btn btn-success"> 
                                                       <input type="button" class="btn btn-danger" value="Cancel" onclick="javascript:history.go(-1);" /> 
                                    </div>


                                </form>
                            </div>
                        </div>
                   
                          
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

<?php // include('includes/footer.php'); ?>

<?php include('includes/script.php'); ?>
 <script>
function showMno(str) {
  if (str.length==0) {
    document.getElementById("livesearchMno").innerHTML="";
    document.getElementById("livesearchMno").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearchMno").innerHTML=this.responseText;
     // document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","crm-livesearching.php?scno="+str,true);
  xmlhttp.send();
}
</script>
        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/select2/js/select2.min.js"></script>
<script src="assets/pages/form-advanced.js"></script>
<?php include('includes/script-bottom.php'); ?>
<script src="http://code.jquery.com/jquery.js"></script>
      <script  >
      $.noConflict();
      $('#add-row').click(function() {
        
    var row = jQuery('.rssRowContainer .rssRow').clone(true);
     jQuery('#txtName', row).attr('id', 'txtName').val("");

  jQuery('.rssRowContainer').append(row).find("input[type='text']").val("");
            

  });
  
  $('body').on('click','.removeNode', function() {
    $(this).closest('.rssRow').remove();
  });
   $('#add-rown').click(function() {
    var row = jQuery('.rssRowContainern .rssRown').clone(true);
     jQuery('.rssRowContainern').append(row);
     $('body').on('click','.removeNoden', function() {
     $(this).closest('.rssRown').remove();
  });
   });
   $('#add-rowm').click(function() {
    var row = jQuery('.rssRowContainerm .rssRowm').clone(true);
     jQuery('.rssRowContainerm').append(row);
     $('body').on('click','.removeNodem', function() {
     $(this).closest('.rssRowm').remove();
  });
   });
   
   
    </script>
    <script>
     // $.noConflict();
     
    </script>
    </body>
</html>